<div class="form-group">
	<input class="form-control" name="nama" rows="3" value="<?php echo $nama?>" hidden></input>
	<input class="form-control" name="email" rows="3" value="<?php echo $email?>" hidden></input>
</div>