<div class="form-group">
	<input class="form-control" name="waktu_respon" rows="3" value="<?php echo $waktu_respon?>" hidden></input>
</div>